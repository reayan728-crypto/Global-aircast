# AirCast: Global Air Quality Intelligence

AI/ML air-quality forecasting, climate-risk and carbon monitoring, and a policy planner, built for the
hackathon theme **Scientific Prediction: AI/ML & Data-Driven Models for Climate Prediction**.

- Live app: https://global-aircast.ai.studio
- Team: Clouder3

## Accessibility add-ons (this repo)

AirCast is designed to work for everyone. These drop-in, dependency-free modules add:

| File | What it does |
|---|---|
| `src/aircast-accessibility.js` | Voice navigation and read-aloud (blind and low-vision users); deaf/hard-of-hearing mode with visual alerts, captions and vibration; sign-language clip panel; high contrast, large text, reduce motion; skip link and ARIA live regions |
| `src/aircast-communication.js` | For deaf and speech-impaired users: type commands, one-tap quick actions, phrase board (tap to speak or show full-screen) |
| `src/aircast-animations.js` | Animated pictograms: 6 AQI faces and 7 action icons (mask, stay indoors, avoid exercise, alert, phone, medical help, best-hours clock) |
| `src/aircast-voice-assistant.js` | Voice assistant for blind and low-vision users, no button: greets when the site opens (time-of-day greeting), answers what the visitor says, then waits for the word "AirCast"; "stop listening" turns it off. Built-in rule-based answers (no external AI or API key); emergency phrases go straight to "Call 108". Works only while the page is open; uses the browser speech service |
| `src/aircast-all-in-one.js` | The three files above combined in the correct order |
| `demo/animation-pack-preview.html` | Open in a browser to preview the animation pack |

## Quick start

Load once, after your page has rendered (the bundle is enough on its own):

```html
<script src="src/aircast-all-in-one.js"></script>
<script>
  AirCastA11y.configure({
    getLang: () => 'en',
    getSummary: () => 'Coimbatore, AQI 73, Satisfactory',
    getForecast: () => 'Cleanest hours are around 12:00.',
    getAdvice: () => 'Sensitive groups should limit prolonged outdoor exertion.'
  });
  AirCastA11y.setAqi(73, 'Coimbatore');                       // call when AQI or city changes
  AirCastAnim.mount(document.getElementById('aqi-icons'), 73); // animated face + actions
  AirCastA11y.announce('Severe smoke expected at 22:00', 'severe');
</script>
```

Voice commands (say "AirCast" first, or just speak after the greeting): "read air quality", "forecast", "health advice", "page 1", "page 2", "simulator", "planner",
"change city to <name>", "help", "stop". Keyboard: Alt+Shift+A opens the panel, Alt+Shift+M toggles the mic.

## Voice assistant languages

Speaks and listens in English, Hindi, Tamil, Telugu, Kannada and Malayalam. A visitor can say a language name (for example "Tamil") at any time to switch; the first visit announces this in all six languages. Core answers (air quality now, is it safe outside, masks, help) are translated in every one of them; other answers are spoken in English. Telugu, Kannada and Malayalam texts should be reviewed by native speakers before public release.

## Honest limits

- The animations are pictograms, **not sign language**. The sign-language panel plays only real, pre-recorded
  clips you supply in `signClips`; without clips it shows text and a "Prototype" label.
- Voice recognition depends on the browser and language (Chrome and Edge work best).
- Hindi and Tamil labels should be reviewed by native speakers.
- CO2e values in the planner are illustrative estimates; this is not medical advice.

## Data sources

Copernicus Sentinel-5P, CAAQMS ground sensors, NASA fire data.
