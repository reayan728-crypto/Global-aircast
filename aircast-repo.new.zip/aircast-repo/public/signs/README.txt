Put your sign-language clips here (e.g. air.mp4, home.mp4, doctor.mp4).
Use only clips you recorded or have permission to use.
