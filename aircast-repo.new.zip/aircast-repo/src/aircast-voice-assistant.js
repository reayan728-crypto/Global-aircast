/*!
 * AirCast Voice Assistant (wake word: just "AirCast", no button)
 * For blind and low-vision users (and anyone who prefers talking).
 *
 * FLOW
 *  1. When the site opens it greets: "Good morning! Have a nice day. I am AirCast. Tell me what you want."
 *     (Browsers block sound until the visitor touches the page once. If so, the greeting plays on the first
 *     tap, key press or screen-reader touch.)
 *  2. It listens for a few seconds. If the visitor says anything, it answers. After each answer it listens again.
 *  3. If nobody speaks, it goes to standby: it only listens for the word "AirCast" to wake up again.
 *  4. Saying "stop listening" or "goodbye" turns it fully off. After 10 quiet minutes it also turns off to save
 *     battery. Tapping the screen once turns it back on.
 *  There is NO mic button. Answers come from a built-in engine (no external AI, no API key).
 *
 * LIMITS: works only while the page is open and visible; uses the browser speech service (Chrome/Edge best).
 * Load AFTER aircast-accessibility.js.
 *
 * FEED IT YOUR LIVE DATA (AirCastA11y.setAqi(aqi, city) alone is enough for basic answers):
 *   AirCastAssistant.configure({
 *     getContext: () => ({ city:'Coimbatore', aqi:73, category:'Satisfactory', pm25:40.8,
 *       bestHour:'12:00', worstHour:'22:00', forecast:'Air improves after noon.',
 *       topDriver:'rush-hour traffic', temp:29, wind:12, humidity:62 })
 *   });
 */
(function () {
  'use strict';
  if (window.AirCastAssistant) return;

  var CFG = {
    ask: null,
    getContext: null,
    idleMinutes: 10,
    activeSeconds: 8, greetDelayMs: 800, showStatus: true, greet: true,
    endpointMs: 800,   // answer this long after you stop talking (faster than waiting for the browser's own final result)
    debug: false,      // true = log timings to the browser console
    setLanguage: null, // (code) => switch the app's own language when the visitor asks for one by voice
    getLang: null,     // () => the app's current language code
   
    wake: /(?:\b(?:air|ayr|aer|eyr)[\s\-]*(?:cast|cost|cas)\b|एयर[\s\-]*कास्ट|ஏர்[\s\-]*காஸ்ட்|ఎయిర్[\s\u200c\u200d]*కాస్ట్|ఏర్[\s\u200c\u200d]*కాస్ట్|ಏರ್[\s\u200c\u200d]*ಕಾಸ್ಟ್|എയർ[\s\u200c\u200d]*കാസ്റ്റ്)/i
  };
  var LOCALES = { en: 'en-IN', hi: 'hi-IN', ta: 'ta-IN', te: 'te-IN', kn: 'kn-IN', ml: 'ml-IN', bn: 'bn-IN', mr: 'mr-IN', gu: 'gu-IN', pa: 'pa-IN', ur: 'ur-IN' };
  var STR = {
    en: {
      btn: 'AirCast voice assistant',
      on: 'AirCast is on. Say AirCast, then ask me anything about the air. Say stop to quiet me.',
      disclosure: 'Note: your browser speech service hears you, and your questions are sent to an AI to answer. This is general information, not medical advice.',
      off: 'AirCast is off.', unsupported: 'Voice is not supported in this browser. Please use Chrome.',
      denied: 'Microphone access was blocked. Please allow the microphone and try again.',
      noAi: 'The AI helper is not connected yet.', error: 'Sorry, I could not answer that. Please try again.',
      paused: 'AirCast is paused to save battery. Tap anywhere to wake me.',
      emergency: 'This may be an emergency. Call 108 now, or ask someone nearby to call. Do not wait for the app.',
      stOff: 'AirCast: off', stWait: 'Say “AirCast”', stListen: 'Listening…', stThink: 'Thinking…', stSpeak: 'Speaking…',
      gm: 'Good morning', ga: 'Good afternoon', ge: 'Good evening', gn: 'Hello',
      nice: 'Have a nice day.', nice2: 'Have a nice evening.', iam: 'I am AirCast.', tell: 'Tell me what you want.',
      intro: 'Say stop listening to turn me off.',
      help: 'I can tell you the air quality, if it is safe to go out, masks, the best time outdoors, and the forecast.',
      langSet: 'Speaking English.',
      langNo: 'Sorry, I can speak English, Hindi, Tamil, Telugu, Kannada and Malayalam.',
      langOffer: 'To change language, say Hindi, Tamil, Telugu, Kannada or Malayalam.'
    },
    hi: {
      btn: 'एयरकास्ट आवाज़ सहायक',
      on: 'एयरकास्ट चालू है। एयरकास्ट कहें, फिर हवा के बारे में कुछ भी पूछें। चुप कराने के लिए रुको कहें।',
      disclosure: 'ध्यान दें: आपकी आवाज़ ब्राउज़र की स्पीच सेवा सुनती है और आपके सवाल जवाब के लिए एआई को भेजे जाते हैं। यह सामान्य जानकारी है, चिकित्सा सलाह नहीं।',
      off: 'एयरकास्ट बंद है।', unsupported: 'इस ब्राउज़र में आवाज़ समर्थित नहीं है। कृपया क्रोम इस्तेमाल करें।',
      denied: 'माइक्रोफ़ोन की अनुमति नहीं मिली। कृपया अनुमति दें और फिर कोशिश करें।',
      noAi: 'एआई सहायक अभी जुड़ा नहीं है।', error: 'क्षमा करें, मैं जवाब नहीं दे सका। कृपया फिर कोशिश करें।',
      paused: 'बैटरी बचाने के लिए एयरकास्ट रुका है। जगाने के लिए कहीं भी टैप करें।',
      emergency: 'यह आपातकाल हो सकता है। अभी 108 पर कॉल करें, या पास के किसी व्यक्ति से कॉल करवाएं। ऐप का इंतज़ार न करें।',
      gm: 'सुप्रभात', ga: 'नमस्कार', ge: 'शुभ संध्या', gn: 'नमस्कार',
      nice: 'आपका दिन शुभ हो।', nice2: 'आपकी शाम शुभ हो।', iam: 'मैं एयरकास्ट हूँ।', tell: 'बताइए, आपको क्या चाहिए?',
      intro: 'मुझे बंद करने के लिए सुनना बंद करो कहें।',
      help: 'मैं वायु गुणवत्ता, बाहर जाना सुरक्षित है या नहीं, मास्क, बाहर का सबसे अच्छा समय और पूर्वानुमान बता सकता हूँ।',
      langSet: 'अब मैं हिंदी में बोल रहा हूँ।',
      langNo: 'क्षमा करें, मैं अंग्रेज़ी, हिंदी, तमिल, तेलुगु, कन्नड़ और मलयालम बोल सकता हूँ।',
      langOffer: 'हिंदी के लिए, हिंदी कहें।'
    },
    ta: {
      btn: 'ஏர்காஸ்ட் குரல் உதவியாளர்',
      on: 'ஏர்காஸ்ட் இயக்கத்தில் உள்ளது. ஏர்காஸ்ட் என்று சொல்லி, காற்றைப் பற்றி எதுவும் கேளுங்கள். என்னை நிறுத்த நிறுத்து என்று சொல்லுங்கள்.',
      disclosure: 'கவனிக்கவும்: உங்கள் உலாவியின் பேச்சு சேவை உங்களைக் கேட்கும், உங்கள் கேள்விகள் பதிலுக்காக AI-க்கு அனுப்பப்படும். இது பொதுத் தகவல், மருத்துவ ஆலோசனை அல்ல.',
      off: 'ஏர்காஸ்ட் அணைக்கப்பட்டது.', unsupported: 'இந்த உலாவியில் குரல் ஆதரிக்கப்படவில்லை. குரோம் பயன்படுத்தவும்.',
      denied: 'மைக்ரோஃபோன் அனுமதி மறுக்கப்பட்டது. அனுமதி அளித்து மீண்டும் முயலவும்.',
      noAi: 'AI உதவியாளர் இன்னும் இணைக்கப்படவில்லை.', error: 'மன்னிக்கவும், பதில் அளிக்க முடியவில்லை. மீண்டும் முயலவும்.',
      paused: 'பேட்டரியைச் சேமிக்க ஏர்காஸ்ட் நிறுத்தப்பட்டது. என்னை எழுப்ப எங்கும் தொடவும்.',
      emergency: 'இது அவசரநிலையாக இருக்கலாம். இப்போதே 108 ஐ அழைக்கவும், அல்லது அருகிலுள்ளவரை அழைக்கச் சொல்லுங்கள். செயலிக்காகக் காத்திருக்க வேண்டாம்.',
      gm: 'காலை வணக்கம்', ga: 'மதிய வணக்கம்', ge: 'மாலை வணக்கம்', gn: 'வணக்கம்',
      nice: 'இனிய நாளாக அமையட்டும்.', nice2: 'இனிய மாலையாக அமையட்டும்.', iam: 'நான் ஏர்காஸ்ட்.', tell: 'உங்களுக்கு என்ன வேண்டும் என்று சொல்லுங்கள்.',
      intro: 'என்னை நிறுத்த கேட்பதை நிறுத்து என்று சொல்லுங்கள்.',
      help: 'காற்றுத் தரம், வெளியே செல்வது பாதுகாப்பானதா, முகக்கவசம், சிறந்த நேரம், முன்னறிவிப்பு ஆகியவற்றைச் சொல்ல முடியும்.',
      langSet: 'இப்போது தமிழில் பேசுகிறேன்.',
      langNo: 'மன்னிக்கவும், நான் ஆங்கிலம், இந்தி, தமிழ், தெலுங்கு, கன்னடம், மலையாளம் பேசுவேன்.',
      langOffer: 'தமிழுக்கு, தமிழ் என்று சொல்லுங்கள்.'
    },
    te: {
      gm: 'శుభోదయం', ga: 'శుభ మధ్యాహ్నం', ge: 'శుభ సాయంత్రం', gn: 'నమస్కారం',
      nice: 'మీ రోజు శుభంగా ఉండాలి.', nice2: 'మీ సాయంత్రం శుభంగా ఉండాలి.',
      iam: 'నేను ఎయిర్‌కాస్ట్.', tell: 'మీకు ఏం కావాలో చెప్పండి.',
      intro: 'నన్ను ఆపడానికి “వినడం ఆపు” అని చెప్పండి.',
      denied: 'మైక్రోఫోన్ అనుమతి నిరాకరించబడింది. అనుమతి ఇచ్చి మళ్లీ ప్రయత్నించండి.',
      unsupported: 'ఈ బ్రౌజర్‌లో వాయిస్ పనిచేయదు. దయచేసి క్రోమ్ వాడండి.',
      error: 'క్షమించండి, నేను సమాధానం ఇవ్వలేకపోయాను. మళ్లీ ప్రయత్నించండి.',
      paused: 'బ్యాటరీ ఆదా చేయడానికి ఎయిర్‌కాస్ట్ ఆగింది. నన్ను లేపడానికి ఎక్కడైనా తాకండి.',
      emergency: 'ఇది అత్యవసర పరిస్థితి కావచ్చు. వెంటనే 108కి కాల్ చేయండి, లేదా దగ్గరలో ఉన్నవారిని కాల్ చేయమని అడగండి.',
      help: 'నేను ప్రస్తుత గాలి నాణ్యత, బయటకు వెళ్లడం సురక్షితమా, మాస్క్, ఉత్తమ సమయం, అంచనా చెప్పగలను.',
      langSet: 'తెలుగులో మాట్లాడుతున్నాను.',
      langNo: 'క్షమించండి, నేను ఇంగ్లీష్, హిందీ, తమిళం, తెలుగు, కన్నడ, మలయాళం మాట్లాడగలను.',
      langOffer: 'తెలుగు కోసం, తెలుగు అని చెప్పండి.'
    },
    kn: {
      gm: 'ಶುಭೋದಯ', ga: 'ಶುಭ ಮಧ್ಯಾಹ್ನ', ge: 'ಶುಭ ಸಂಜೆ', gn: 'ನಮಸ್ಕಾರ',
      nice: 'ನಿಮ್ಮ ದಿನ ಶುಭವಾಗಿರಲಿ.', nice2: 'ನಿಮ್ಮ ಸಂಜೆ ಶುಭವಾಗಿರಲಿ.',
      iam: 'ನಾನು ಏರ್‌ಕಾಸ್ಟ್.', tell: 'ನಿಮಗೆ ಏನು ಬೇಕು ಹೇಳಿ.',
      intro: 'ನನ್ನನ್ನು ನಿಲ್ಲಿಸಲು “ಕೇಳುವುದನ್ನು ನಿಲ್ಲಿಸು” ಎಂದು ಹೇಳಿ.',
      denied: 'ಮೈಕ್ರೋಫೋನ್ ಅನುಮತಿ ನಿರಾಕರಿಸಲಾಗಿದೆ. ಅನುಮತಿ ನೀಡಿ ಮತ್ತೆ ಪ್ರಯತ್ನಿಸಿ.',
      unsupported: 'ಈ ಬ್ರೌಸರ್‌ನಲ್ಲಿ ಧ್ವನಿ ಬೆಂಬಲವಿಲ್ಲ. ದಯವಿಟ್ಟು ಕ್ರೋಮ್ ಬಳಸಿ.',
      error: 'ಕ್ಷಮಿಸಿ, ನಾನು ಉತ್ತರಿಸಲಾಗಲಿಲ್ಲ. ದಯವಿಟ್ಟು ಮತ್ತೆ ಪ್ರಯತ್ನಿಸಿ.',
      paused: 'ಬ್ಯಾಟರಿ ಉಳಿಸಲು ಏರ್‌ಕಾಸ್ಟ್ ನಿಂತಿದೆ. ನನ್ನನ್ನು ಎಬ್ಬಿಸಲು ಎಲ್ಲಿಯಾದರೂ ಮುಟ್ಟಿ.',
      emergency: 'ಇದು ತುರ್ತು ಪರಿಸ್ಥಿತಿಯಾಗಿರಬಹುದು. ಈಗಲೇ 108ಕ್ಕೆ ಕರೆ ಮಾಡಿ, ಅಥವಾ ಹತ್ತಿರದವರಿಗೆ ಕರೆ ಮಾಡಲು ಹೇಳಿ.',
      help: 'ನಾನು ಈಗಿನ ಗಾಳಿಯ ಗುಣಮಟ್ಟ, ಹೊರಗೆ ಹೋಗುವುದು ಸುರಕ್ಷಿತವೇ, ಮಾಸ್ಕ್, ಉತ್ತಮ ಸಮಯ ಮತ್ತು ಮುನ್ಸೂಚನೆ ಹೇಳಬಲ್ಲೆ.',
      langSet: 'ಕನ್ನಡದಲ್ಲಿ ಮಾತನಾಡುತ್ತಿದ್ದೇನೆ.',
      langNo: 'ಕ್ಷಮಿಸಿ, ನಾನು ಇಂಗ್ಲಿಷ್, ಹಿಂದಿ, ತಮಿಳು, ತೆಲುಗು, ಕನ್ನಡ, ಮಲಯಾಳಂ ಮಾತನಾಡಬಲ್ಲೆ.',
      langOffer: 'ಕನ್ನಡಕ್ಕಾಗಿ, ಕನ್ನಡ ಎಂದು ಹೇಳಿ.'
    },
    ml: {
      gm: 'സുപ്രഭാതം', ga: 'ശുഭ ഉച്ച', ge: 'ശുഭ സായാഹ്നം', gn: 'നമസ്കാരം',
      nice: 'നിങ്ങളുടെ ദിവസം നല്ലതാകട്ടെ.', nice2: 'നിങ്ങളുടെ സായാഹ്നം നല്ലതാകട്ടെ.',
      iam: 'ഞാൻ എയർകാസ്റ്റ്.', tell: 'നിങ്ങൾക്ക് എന്താണ് വേണ്ടതെന്ന് പറയൂ.',
      intro: 'എന്നെ നിർത്താൻ “കേൾക്കുന്നത് നിർത്തൂ” എന്ന് പറയൂ.',
      denied: 'മൈക്രോഫോൺ അനുമതി നിഷേധിച്ചു. അനുമതി നൽകി വീണ്ടും ശ്രമിക്കൂ.',
      unsupported: 'ഈ ബ്രൗസറിൽ ശബ്ദം പിന്തുണയ്ക്കുന്നില്ല. ദയവായി ക്രോം ഉപയോഗിക്കൂ.',
      error: 'ക്ഷമിക്കണം, എനിക്ക് ഉത്തരം നൽകാനായില്ല. വീണ്ടും ശ്രമിക്കൂ.',
      paused: 'ബാറ്ററി ലാഭിക്കാൻ എയർകാസ്റ്റ് നിർത്തി. എന്നെ ഉണർത്താൻ എവിടെയെങ്കിലും തൊടൂ.',
      emergency: 'ഇത് അടിയന്തര സാഹചര്യമായിരിക്കാം. ഉടൻ 108 വിളിക്കൂ, അല്ലെങ്കിൽ അടുത്തുള്ളവരോട് വിളിക്കാൻ പറയൂ.',
      help: 'ഇപ്പോഴത്തെ വായു നിലവാരം, പുറത്തിറങ്ങുന്നത് സുരക്ഷിതമാണോ, മാസ്ക്, നല്ല സമയം, പ്രവചനം എന്നിവ എനിക്ക് പറയാനാകും.',
      langSet: 'മലയാളത്തിൽ സംസാരിക്കുന്നു.',
      langNo: 'ക്ഷമിക്കണം, എനിക്ക് ഇംഗ്ലീഷ്, ഹിന്ദി, തമിഴ്, തെലുങ്ക്, കന്നഡ, മലയാളം സംസാരിക്കാം.',
      langOffer: 'മലയാളത്തിന്, മലയാളം എന്ന് പറയൂ.'
    }
  };
  var EMERGENCY = /can'?t breathe|cannot breathe|difficulty breathing|trouble breathing|chest pain|heart attack|faint(?:ed|ing)?|unconscious|passed out|choking|asthma attack|सांस नहीं|सांस लेने में तकलीफ|सीने में दर्द|बेहोश|மூச்சு (?:விட|திணறல்)|நெஞ்சு வலி|மயக்கம்/i;
  var STOP = /^(?:stop|quiet|cancel|enough|be quiet|रुको|बस|चुप|நிறுத்து)\b/i;
  var STOPLISTEN = /\b(?:stop listening|go to sleep|goodbye|good bye|turn off|switch off)\b|सुनना बंद|अलविदा|बंद करो|கேட்பதை நிறுத்து/i;
  var CITY = /\b(?:change|set|switch)\s+(?:the\s+)?city\s+to\s+(.+)/i;
  var LOCAL_INTENTS = { page1: 1, page2: 1, simulator: 1, planner: 1, help: 1 };

  var st = { mode: 'active', rec: null, busy: false, woke: false, activeTimer: null, idleTimer: null, greeted: false, gestureArmed: false, resumeArmed: false, history: [], epTimer: null, epDone: false, fails: 0, sayId: 0 };
  var ui = {};
  var INTRO = 'aircast_assistant_intro';

  function langCode() {
    var l = st.lang || '';
    try { if (!l && CFG.getLang) l = CFG.getLang() || ''; } catch (e) { /* ignore */ }
    try { if (!l) l = localStorage.getItem('lang') || ''; } catch (e) { /* ignore */ }
    l = String(l || document.documentElement.lang || 'en').toLowerCase().split(/[-_]/)[0];
    return STR[l] ? l : 'en';   // languages without voice strings fall back to English
  }
  function locale() { return LOCALES[langCode()] || 'en-IN'; }
  function t(k) { var l = langCode(); return (STR[l] && STR[l][k]) || STR.en[k] || k; }
  function A() { return window.AirCastA11y || null; }

  /* ------------------------------- sounds -------------------------------- */
  var ac = null;
  function beep(freqs) {
    try {
      ac = ac || new (window.AudioContext || window.webkitAudioContext)();
      var now = ac.currentTime;
      freqs.forEach(function (f, i) {
        var o = ac.createOscillator(), g = ac.createGain();
        o.frequency.value = f; o.connect(g); g.connect(ac.destination);
        g.gain.setValueAtTime(0.0001, now + i * 0.14);
        g.gain.exponentialRampToValueAtTime(0.25, now + i * 0.14 + 0.02);
        g.gain.exponentialRampToValueAtTime(0.0001, now + i * 0.14 + 0.12);
        o.start(now + i * 0.14); o.stop(now + i * 0.14 + 0.13);
      });
    } catch (e) { /* ignore */ }
  }

  /* ------------------------------ speaking ------------------------------- */
  var T0 = 0;
  function mark(m) { if (CFG.debug && window.console) console.log('[AirCast] ' + m + ' +' + Math.round(Date.now() - T0) + 'ms'); }
  // Prefer an on-device voice: network voices can take seconds to start speaking.
  function pickVoice(loc) {
    try {
      var vs = (window.speechSynthesis.getVoices && window.speechSynthesis.getVoices()) || [];
      var base = String(loc).slice(0, 2).toLowerCase();
      var exact = vs.filter(function (v) { return v.lang && v.lang.replace('_', '-').toLowerCase() === String(loc).toLowerCase(); });
      var same = exact.length ? exact : vs.filter(function (v) { return v.lang && v.lang.toLowerCase().indexOf(base) === 0; });
      var local = same.filter(function (v) { return v.localService; });
      return local[0] || same[0] || null;
    } catch (e) { return null; }
  }
  // Speaks sentence by sentence (first audio starts sooner). done() runs once, when the last sentence ends.
  // text = "sentence" (in language `want`)  OR  [["sentence", "hi"], ["sentence", "ta"], ...] (each in its own voice).
  function say(text, want, done, onstart) {
    if (!('speechSynthesis' in window)) { done(); return; }
    var id = ++st.sayId, finished = false, items = [], total = 0;
    var src = Array.isArray(text) ? text : [[text, want]];
    src.forEach(function (pr) {
      var loc = LOCALES[pr[1]] || 'en-IN', voice = pickVoice(loc);
      (String(pr[0]).match(/[^.!?।]+[.!?।]*/g) || [String(pr[0])]).forEach(function (x) {
        x = x.trim(); if (x) { items.push({ t: x, loc: loc, voice: voice }); total += x.length; }
      });
    });
    var guard = setTimeout(fin, 4000 + total * 110);
    function fin() { if (finished || id !== st.sayId) return; finished = true; clearTimeout(guard); done(); }
    try { window.speechSynthesis.cancel(); } catch (e) { /* ignore */ }
    setTimeout(function () {
      if (id !== st.sayId) return;
      items.forEach(function (it, i) {
        var u = new SpeechSynthesisUtterance(it.t);
        u.lang = it.loc; if (it.voice) u.voice = it.voice; u.rate = 1.05;
        if (i === 0) u.onstart = function () { mark('speech started'); if (onstart) onstart(); };
        if (i === items.length - 1) { u.onend = fin; u.onerror = fin; }
        try { window.speechSynthesis.speak(u); } catch (e) { fin(); }
      });
    }, 60);
  }
  function speak(text, lang) {
    if (!text) return;
    stopRec(); setStatus('stSpeak');
    var a = A(); if (a && a.caption) a.caption(Array.isArray(text) ? text.map(function (p) { return p[0]; }).join(' ') : text);
    say(text, lang || langCode(), function () { mark('speech ended'); resume(); });
  }
  function cancelSpeech() { try { window.speechSynthesis.cancel(); } catch (e) { /* ignore */ } }
  // For speech started by aircast-accessibility.js (it gives no callback): wait until it has really finished.
  function waitQuiet(cb) {
    setTimeout(function () {
      var tries = 0;
      var iv = setInterval(function () {
        tries++;
        var speaking = 'speechSynthesis' in window && window.speechSynthesis.speaking;
        if (!speaking || tries > 450) { clearInterval(iv); setTimeout(cb, 80); }
      }, 100);
    }, 250);
  }
  function clean(text) {
    var s = String(text || '').replace(/```[\s\S]*?```/g, ' ').replace(/https?:\/\/\S+/g, ' ')
      .replace(/[*#_`>|~]/g, ' ').replace(/\s+/g, ' ').trim();
    if (s.length > 700) { s = s.slice(0, 700); var i = Math.max(s.lastIndexOf('. '), s.lastIndexOf('। ')); if (i > 200) s = s.slice(0, i + 1); }
    return s;
  }

  /* ----------------------------- recognition ----------------------------- */
  function startRec() {
    if (st.mode === 'off' || st.rec) return true;
    var SR = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!SR) { st.mode = 'off'; return false; }
    st.epDone = false;
    var r = new SR();
    r.lang = locale(); r.continuous = true; r.interimResults = true; r.maxAlternatives = 3;
    r.onresult = function (e) {
      st.fails = 0;
      for (var i = e.resultIndex; i < e.results.length; i++) {
        var res = e.results[i];
        if (!res.isFinal) {
          // Interim results arrive fast: react to the wake word immediately and keep the listening window open.
          if (st.mode === 'active') startActiveTimer(6);
          else if (st.mode === 'standby' && !st.woke && CFG.wake.test(res[0].transcript)) { st.woke = true; cancelSpeech(); beep([880, 1175]); }
          scheduleEndpoint(res[0].transcript);
          continue;
        }
        clearTimeout(st.epTimer);
        if (st.epDone) { st.epDone = false; continue; }   // already handled from the interim text
        var already = st.woke; st.woke = false;
        var alts = [];
        for (var j = 0; j < res.length; j++) alts.push(res[j].transcript);
        heard(alts, already);
      }
    };
    r.onerror = function (ev) {
      if (ev.error === 'not-allowed' || ev.error === 'service-not-allowed') { goOff(); speak(t('denied')); }
      else if (ev.error === 'network') {
        st.fails++;
        var ca = A(); if (st.fails === 3 && ca && ca.caption) ca.caption('Voice service not reachable. Check your internet connection.');
      }
    };
    r.onend = function () {
      st.rec = null;
      if (st.mode !== 'off' && !st.busy && !(window.speechSynthesis && window.speechSynthesis.speaking)) setTimeout(startRec, st.fails ? Math.min(3000, 400 * st.fails) : 120);
    };
    try { r.start(); st.rec = r; } catch (e) { st.rec = null; }
    return true;
  }
  function stopRec() {
    var r = st.rec; st.rec = null;
    if (r) { r.onend = null; r.onresult = null; try { r.abort(); } catch (e) { /* ignore */ } }
  }
  // Don't wait for the browser to decide you're done: answer ~0.8s after the words stop changing.
  function scheduleEndpoint(txt) {
    clearTimeout(st.epTimer);
    if (!txt) return;
    st.epTimer = setTimeout(function () {
      if (st.mode === 'off' || st.busy) return;
      var already = st.woke; st.woke = false;
      st.epDone = true;
      T0 = Date.now(); mark('endpoint: ' + txt);
      heard([txt], already);
    }, CFG.endpointMs);
  }
  function stripWake(text) { return String(text || '').replace(CFG.wake, ' ').replace(/^[\s,.!?\-]+/, '').trim(); }

  function heard(alts, alreadyBeeped) {
    resetIdle();
    var text = alts[0] || '';
    var wakeAlt = alts.filter(function (a) { return CFG.wake.test(a); })[0];
    if (st.mode === 'standby') {
      if (!wakeAlt) return;
      if (!alreadyBeeped) { cancelSpeech(); beep([880, 1175]); }
      var rest = stripWake(wakeAlt);
      st.mode = 'active'; setStatus('stListen');
      if (rest.length > 2) process(rest); else startActiveTimer();
      return;
    }
    if (st.mode === 'active') {
      clearTimeout(st.activeTimer);
      var q = stripWake(wakeAlt || text);
      if (!q) { startActiveTimer(); return; }
      process(q);
    }
  }

  /* ------------------------------ listening modes ------------------------ */
  function openActive() {
    if (st.mode === 'off') return;
    st.mode = 'active'; st.busy = false;
    setStatus('stListen'); startRec(); startActiveTimer();
  }
  function startActiveTimer(sec) {
    clearTimeout(st.activeTimer);
    st.activeTimer = setTimeout(toStandby, (sec || CFG.activeSeconds) * 1000);
  }
  function toStandby() { if (st.mode !== 'active') return; st.mode = 'standby'; setStatus('stWait'); startRec(); }
  function resume() { if (st.mode !== 'off') openActive(); }
  function resetIdle() {
    clearTimeout(st.idleTimer);
    if (!CFG.idleMinutes) return;
    st.idleTimer = setTimeout(function () { if (st.mode === 'standby') goOff(); else resetIdle(); }, CFG.idleMinutes * 60000);
  }

  /* ------------------------------ understanding -------------------------- */
  /* ----------------------------- languages ------------------------------- */
  var ORDER = ['en', 'hi', 'ta', 'te', 'kn', 'ml'];
  var LANGNAMES = [
    ['en', /\b(?:english|angrezi)\b|अंग्रेज़ी|अंग्रेजी|इंग्लिश|ஆங்கிலம்|ఇంగ్లీష్|ಇಂಗ್ಲಿಷ್|ഇംഗ്ലീഷ്/i],
    ['hi', /\bhindi\b|हिंदी|हिन्दी|இந்தி|హిందీ|ಹಿಂದಿ|ഹിന്ദി/i],
    ['ta', /\b(?:tamil|thamizh)\b|தமிழ்|तमिल|తమిళం|ತಮಿಳು|തമിഴ്/i],
    ['te', /\btelugu\b|తెలుగు|तेलुगु|தெலுங்கு|ತೆಲುಗು|തെലുങ്ക്/i],
    ['kn', /\bkannada\b|ಕನ್ನಡ|कन्नड़|कन्नड|கன்னடம்|కన్నడ|കന്നഡ/i],
    ['ml', /\bmalayalam\b|മലയാളം|मलयालम|மலையாளம்|మలయాళం|ಮಲಯಾಳಂ/i]
  ];
  var OTHER_LANGS = /\b(?:bengali|bangla|marathi|gujarati|punjabi|urdu|odia|oriya|assamese|spanish|french|german|arabic|chinese|japanese)\b|বাংলা|मराठी|ગુજરાતી|ਪੰਜਾਬੀ|اردو|ଓଡ଼ିଆ/i;
  var LANGWORD = /\blanguage\b|भाषा|மொழி|భాష|ಭಾಷೆ|ഭാഷ/i;
  function langRequest(q) {
    if (q.split(/\s+/).length > 7) return null;
    for (var i = 0; i < LANGNAMES.length; i++) if (LANGNAMES[i][1].test(q)) return LANGNAMES[i][0];
    if (OTHER_LANGS.test(q)) return 'other';
    if (LANGWORD.test(q)) return 'list';
    return null;
  }
  function offerParts() { return ORDER.map(function (c) { return [STR[c].langOffer, c]; }); }
  // Switches the assistant (voice + listening language) and the app's own language.
  function setLang(code, quiet) {
    if (!STR[code]) return;
    st.lang = code;
    try { localStorage.setItem('lang', code); localStorage.setItem('aircast_lang', code); } catch (e) { /* ignore */ }
    document.documentElement.lang = code;
    try { if (CFG.setLanguage) CFG.setLanguage(code); } catch (e) { /* ignore */ }
    try { window.dispatchEvent(new CustomEvent('aircast:language', { detail: { lang: code } })); } catch (e) { /* ignore */ }
    stopRec();   // listening restarts in the new language after the reply
    if (!quiet) speak(t('langSet') + ' ' + t('help'));
  }
  function handleLang(lg) {
    if (lg === 'other') { speak(t('langNo')); return; }
    if (lg === 'list') { speak(offerParts()); return; }
    setLang(lg);
  }

  function process(q) {
    q = (q || '').trim();
    if (!q) return;
    mark('process: ' + q);
    if (STOPLISTEN.test(q)) { goOff(); return; }
    if (STOP.test(q)) { cancelSpeech(); startActiveTimer(); return; }
    var lg = langRequest(q);
    if (lg) { handleLang(lg); return; }
    var a = A();
    if (EMERGENCY.test(q)) {
      if (a && a.announce) a.announce(t('emergency'), 'severe'); else speak(t('emergency'));
      stopRec(); waitQuiet(resume);
      return;
    }
    var city = q.match(CITY);
    if (city && a) { stopRec(); a.command('change city to ' + city[1]); waitQuiet(resume); return; }
    var id = a && a.intent ? a.intent(q) : null;
    var short = q.split(/\s+/).length <= 5;
    if (a && id && LOCAL_INTENTS[id] && short) { stopRec(); a.command(q); waitQuiet(resume); return; }
    if (CFG.ask) { ask(q); return; }
    answerLocally(q);
  }

  /* ---------------------- built-in answer engine (no AI) ------------------ */
  var ADV = {
    en: {
      good: 'The air is good. Outdoor activity is fine for everyone.',
      satisfactory: 'The air is acceptable. Very sensitive people should take it easy on long outdoor exertion.',
      moderate: 'People with asthma, heart or lung conditions, children and older adults should reduce long or hard outdoor exercise.',
      poor: 'Everyone should reduce hard outdoor exercise. Sensitive people should stay indoors if possible. A well-fitted N95 mask helps outdoors.',
      veryPoor: 'Avoid outdoor exercise. Stay indoors with windows closed, and wear a well-fitted N95 mask if you must go out.',
      severe: 'Stay indoors with windows closed and avoid all outdoor activity. If you have trouble breathing, call 108.'
    },
    hi: {
      good: 'हवा अच्छी है। सभी के लिए बाहर गतिविधि ठीक है।',
      satisfactory: 'हवा संतोषजनक है। बहुत संवेदनशील लोग लंबे समय तक कठिन परिश्रम से बचें।',
      moderate: 'दमा, हृदय या फेफड़ों की समस्या वाले लोग, बच्चे और बुज़ुर्ग बाहर लंबा या कठिन व्यायाम कम करें।',
      poor: 'सभी बाहर कठिन व्यायाम कम करें। संवेदनशील लोग हो सके तो घर के अंदर रहें। बाहर सही फिट वाला N95 मास्क मदद करता है।',
      veryPoor: 'बाहर व्यायाम न करें। खिड़कियां बंद करके घर के अंदर रहें, ज़रूरी हो तो सही फिट वाला N95 मास्क पहनकर निकलें।',
      severe: 'घर के अंदर खिड़कियां बंद रखें और बाहर की सभी गतिविधि से बचें। सांस लेने में तकलीफ हो तो 108 पर कॉल करें।'
    },
    ta: {
      good: 'காற்று நன்றாக உள்ளது. அனைவரும் வெளியே செயல்படலாம்.',
      satisfactory: 'காற்றின் தரம் திருப்திகரம். மிகவும் உணர்திறன் உள்ளவர்கள் நீண்ட கடின உழைப்பைத் தவிர்க்கவும்.',
      moderate: 'ஆஸ்துமா, இதயம் அல்லது நுரையீரல் பிரச்சினை உள்ளவர்கள், குழந்தைகள் மற்றும் முதியவர்கள் வெளியே நீண்ட அல்லது கடினமான உடற்பயிற்சியைக் குறைக்கவும்.',
      poor: 'அனைவரும் வெளியே கடினமான உடற்பயிற்சியைக் குறைக்கவும். உணர்திறன் உள்ளவர்கள் முடிந்தால் வீட்டிற்குள் இருக்கவும். வெளியே சரியாகப் பொருந்தும் N95 முகக்கவசம் உதவும்.',
      veryPoor: 'வெளியே உடற்பயிற்சி வேண்டாம். ஜன்னல்களை மூடி வீட்டிற்குள் இருங்கள்; வெளியே செல்ல வேண்டுமெனில் சரியாகப் பொருந்தும் N95 முகக்கவசம் அணியுங்கள்.',
      severe: 'ஜன்னல்களை மூடி வீட்டிற்குள் இருங்கள்; வெளிப்புற செயல்களைத் தவிர்க்கவும். மூச்சுத் திணறல் இருந்தால் 108 ஐ அழைக்கவும்.'
    },
    te: {
      good: 'గాలి నాణ్యత బాగుంది. అందరూ బయట కార్యకలాపాలు చేయవచ్చు.',
      satisfactory: 'గాలి నాణ్యత సంతృప్తికరం. చాలా సున్నితమైనవారు ఎక్కువసేపు కష్టమైన పని చేయకండి.',
      moderate: 'ఆస్తమా, గుండె లేదా ఊపిరితిత్తుల సమస్యలు ఉన్నవారు, పిల్లలు, వృద్ధులు బయట ఎక్కువసేపు లేదా కఠినమైన వ్యాయామం తగ్గించాలి.',
      poor: 'అందరూ బయట కఠినమైన వ్యాయామం తగ్గించాలి. సున్నితమైనవారు వీలైతే ఇంట్లోనే ఉండాలి. బయట సరిగ్గా సరిపోయే N95 మాస్క్ సహాయపడుతుంది.',
      veryPoor: 'బయట వ్యాయామం చేయకండి. కిటికీలు మూసి ఇంట్లో ఉండండి; తప్పనిసరిగా వెళ్ళాలంటే సరిగ్గా సరిపోయే N95 మాస్క్ ధరించండి.',
      severe: 'కిటికీలు మూసి ఇంట్లోనే ఉండండి, బయట కార్యకలాపాలన్నీ మానుకోండి. శ్వాస తీసుకోవడంలో ఇబ్బంది ఉంటే 108కి కాల్ చేయండి.'
    },
    kn: {
      good: 'ಗಾಳಿಯ ಗುಣಮಟ್ಟ ಚೆನ್ನಾಗಿದೆ. ಎಲ್ಲರೂ ಹೊರಗೆ ಚಟುವಟಿಕೆ ಮಾಡಬಹುದು.',
      satisfactory: 'ಗಾಳಿಯ ಗುಣಮಟ್ಟ ಸಮಾಧಾನಕರ. ತುಂಬಾ ಸೂಕ್ಷ್ಮ ಜನರು ಹೆಚ್ಚು ಹೊತ್ತು ಕಠಿಣ ಶ್ರಮ ಮಾಡಬೇಡಿ.',
      moderate: 'ಆಸ್ತಮಾ, ಹೃದಯ ಅಥವಾ ಶ್ವಾಸಕೋಶದ ತೊಂದರೆ ಇರುವವರು, ಮಕ್ಕಳು ಮತ್ತು ವೃದ್ಧರು ಹೊರಗೆ ಹೆಚ್ಚು ಹೊತ್ತು ಅಥವಾ ಕಠಿಣ ವ್ಯಾಯಾಮ ಕಡಿಮೆ ಮಾಡಿ.',
      poor: 'ಎಲ್ಲರೂ ಹೊರಗೆ ಕಠಿಣ ವ್ಯಾಯಾಮ ಕಡಿಮೆ ಮಾಡಿ. ಸೂಕ್ಷ್ಮ ಜನರು ಸಾಧ್ಯವಾದರೆ ಮನೆಯೊಳಗೆ ಇರಿ. ಹೊರಗೆ ಸರಿಯಾಗಿ ಹೊಂದುವ N95 ಮಾಸ್ಕ್ ಸಹಾಯ ಮಾಡುತ್ತದೆ.',
      veryPoor: 'ಹೊರಗೆ ವ್ಯಾಯಾಮ ಮಾಡಬೇಡಿ. ಕಿಟಕಿಗಳನ್ನು ಮುಚ್ಚಿ ಮನೆಯೊಳಗೆ ಇರಿ; ಹೊರಗೆ ಹೋಗಲೇಬೇಕಾದರೆ ಸರಿಯಾಗಿ ಹೊಂದುವ N95 ಮಾಸ್ಕ್ ಧರಿಸಿ.',
      severe: 'ಕಿಟಕಿಗಳನ್ನು ಮುಚ್ಚಿ ಮನೆಯೊಳಗೇ ಇರಿ, ಹೊರಗಿನ ಎಲ್ಲಾ ಚಟುವಟಿಕೆ ತಪ್ಪಿಸಿ. ಉಸಿರಾಟದ ತೊಂದರೆ ಇದ್ದರೆ 108ಕ್ಕೆ ಕರೆ ಮಾಡಿ.'
    },
    ml: {
      good: 'വായുവിന്റെ നിലവാരം നല്ലതാണ്. എല്ലാവർക്കും പുറത്ത് പ്രവർത്തനങ്ങൾ ചെയ്യാം.',
      satisfactory: 'വായുവിന്റെ നിലവാരം തൃപ്തികരമാണ്. വളരെ സെൻസിറ്റീവ് ആയവർ ദീർഘനേരം കഠിനാധ്വാനം ഒഴിവാക്കുക.',
      moderate: 'ആസ്ത്മ, ഹൃദയം അല്ലെങ്കിൽ ശ്വാസകോശ പ്രശ്നമുള്ളവർ, കുട്ടികൾ, മുതിർന്നവർ പുറത്ത് ദീർഘനേരമോ കഠിനമായതോ ആയ വ്യായാമം കുറയ്ക്കുക.',
      poor: 'എല്ലാവരും പുറത്ത് കഠിനമായ വ്യായാമം കുറയ്ക്കുക. സെൻസിറ്റീവ് ആയവർ കഴിയുമെങ്കിൽ വീടിനുള്ളിൽ തുടരുക. പുറത്ത് നന്നായി ഇണങ്ങുന്ന N95 മാസ്ക് സഹായിക്കും.',
      veryPoor: 'പുറത്ത് വ്യായാമം ചെയ്യരുത്. ജനലുകൾ അടച്ച് വീടിനുള്ളിൽ തുടരുക; പോകേണ്ടി വന്നാൽ നന്നായി ഇണങ്ങുന്ന N95 മാസ്ക് ധരിക്കുക.',
      severe: 'ജനലുകൾ അടച്ച് വീടിനുള്ളിൽ തന്നെ തുടരുക, പുറത്തുള്ള എല്ലാ പ്രവർത്തനങ്ങളും ഒഴിവാക്കുക. ശ്വസിക്കാൻ ബുദ്ധിമുട്ടുണ്ടെങ്കിൽ 108 വിളിക്കുക.'
    }
  };
  var MASK = {
    en: 'A well-fitted N95 or FFP2 respirator filters fine particles. Cloth or surgical masks do not filter them well. Wear one outdoors when the air is poor or worse.',
    hi: 'सही फिट वाला N95 या FFP2 मास्क महीन कणों को रोकता है। कपड़े या सर्जिकल मास्क इन्हें अच्छी तरह नहीं रोकते। हवा खराब हो तो बाहर इसे पहनें।',
    ta: 'சரியாகப் பொருந்தும் N95 அல்லது FFP2 முகக்கவசம் நுண்துகள்களை வடிகட்டும். துணி அல்லது அறுவை சிகிச்சை முகக்கவசங்கள் அவற்றை நன்றாக வடிகட்டாது. காற்று மோசமாக இருந்தால் வெளியே அணியுங்கள்.'
    ,
    te: 'సరిగ్గా సరిపోయే N95 లేదా FFP2 మాస్క్ సూక్ష్మ కణాలను అడ్డుకుంటుంది. బట్ట లేదా సర్జికల్ మాస్కులు వాటిని బాగా అడ్డుకోవు. గాలి చెడ్డగా ఉంటే బయట ధరించండి.',
    kn: 'ಸರಿಯಾಗಿ ಹೊಂದುವ N95 ಅಥವಾ FFP2 ಮಾಸ್ಕ್ ಸೂಕ್ಷ್ಮ ಕಣಗಳನ್ನು ತಡೆಯುತ್ತದೆ. ಬಟ್ಟೆ ಅಥವಾ ಸರ್ಜಿಕಲ್ ಮಾಸ್ಕ್ ಅವನ್ನು ಚೆನ್ನಾಗಿ ತಡೆಯುವುದಿಲ್ಲ. ಗಾಳಿ ಕೆಟ್ಟದಾಗಿದ್ದರೆ ಹೊರಗೆ ಧರಿಸಿ.',
    ml: 'നന്നായി ഇണങ്ങുന്ന N95 അല്ലെങ്കിൽ FFP2 മാസ്ക് സൂക്ഷ്മ കണങ്ങളെ തടയും. തുണി അല്ലെങ്കിൽ സർജിക്കൽ മാസ്കുകൾ അവയെ നന്നായി തടയില്ല. വായു മോശമാണെങ്കിൽ പുറത്ത് ധരിക്കുക.'
  };
  var FALLBACK = {
    en: 'I can tell you the air quality now, whether it is safe to go outside, masks, the best time outdoors, and the forecast. You can also say page 1, page 2, simulator or planner.',
    hi: 'मैं अभी की वायु गुणवत्ता, बाहर जाना सुरक्षित है या नहीं, मास्क, बाहर का सबसे अच्छा समय और पूर्वानुमान बता सकता हूँ। आप पेज 1, पेज 2, सिम्युलेटर या योजना भी बोल सकते हैं।',
    ta: 'தற்போதைய காற்றுத் தரம், வெளியே செல்வது பாதுகாப்பானதா, முகக்கவசம், வெளியே செல்ல சிறந்த நேரம், முன்னறிவிப்பு ஆகியவற்றைச் சொல்ல முடியும். பக்கம் 1, பக்கம் 2, சிமுலேட்டர் அல்லது திட்டம் என்றும் சொல்லலாம்.'
    ,
    te: 'నేను ప్రస్తుత గాలి నాణ్యత, బయటకు వెళ్లడం సురక్షితమా, మాస్క్, ఉత్తమ సమయం, అంచనా చెప్పగలను.',
    kn: 'ನಾನು ಈಗಿನ ಗಾಳಿಯ ಗುಣಮಟ್ಟ, ಹೊರಗೆ ಹೋಗುವುದು ಸುರಕ್ಷಿತವೇ, ಮಾಸ್ಕ್, ಉತ್ತಮ ಸಮಯ ಮತ್ತು ಮುನ್ಸೂಚನೆ ಹೇಳಬಲ್ಲೆ.',
    ml: 'ഇപ്പോഴത്തെ വായു നിലവാരം, പുറത്തിറങ്ങുന്നത് സുരക്ഷിതമാണോ, മാസ്ക്, നല്ല സമയം, പ്രവചനം എന്നിവ എനിക്ക് പറയാനാകും.'
  };
  function levelOf(a) { return a <= 50 ? 'good' : a <= 100 ? 'satisfactory' : a <= 200 ? 'moderate' : a <= 300 ? 'poor' : a <= 400 ? 'veryPoor' : 'severe'; }
  function pick(tbl, l) { return tbl[l] ? { text: tbl[l], lang: l } : { text: tbl.en, lang: 'en' }; }

  // Returns { text, lang }. Hindi/Tamil are available for the core answers; other answers use English.
  function localAnswer(q, ctx) {
    var l = langCode(), a = A(), s = (a && a.status && a.status()) || {};
    var aqi = ctx.aqi != null ? Number(ctx.aqi) : s.aqi;
    var city = ctx.city || s.place || '';
    var have = typeof aqi === 'number' && !isNaN(aqi);
    var lvl = have ? levelOf(aqi) : null;
    function en(text) { return { text: text, lang: 'en' }; }
    function advice() { var tbl = ADV[l] || ADV.en, lg = ADV[l] ? l : 'en'; return { text: tbl[lvl], lang: lg }; }
    var noData = en('Air quality data is not loaded yet. Please select a city first.');
    var x = q.toLowerCase();

    if (/what is (?:the )?(?:aqi|air quality index|pm ?2\.?5)/.test(x))
      return en('The air quality index is a number showing how clean or polluted the air is. Higher means worse. PM2.5 is fine dust small enough to reach deep into the lungs.');
    if (/hospital|clinic|doctor|अस्पताल|மருத்துவமனை/.test(x))
      return en('Say page 2 and open the clean-air hospitals section. In an emergency, call 108.');
    if (/mask|n95|मास्क|முகக்கவசம்|మాస్క్|ಮಾಸ್ಕ್|മാസ്ക്/.test(x)) { var m = ADV[l] ? { text: MASK[l], lang: l } : en(MASK.en); return m; }
    if (/child|kid|baby|old age|elder|asthma|copd|pregnan|बच्च|बुज़ुर्ग|दमा|குழந்தை|ஆஸ்துமா|పిల్ల|ಮಕ್ಕಳ|കുട്ടി/.test(x))
      return have ? (function () { var r = advice(); if (r.lang === 'en') r.text += ' Keep any reliever medicine your doctor prescribed within reach.'; return r; })() : noData;
    if (/window|indoor|ventilat|खिड़की|ஜன்னல்/.test(x))
      return en('Keep windows closed when the air is poor or worse, and open them when it improves, usually around midday.');
    if (/best (?:time|hour)|cleanest|when (?:should|can|is).*(?:go|walk|run|outside|exercise)|सबसे अच्छा समय|சிறந்த நேரம்/.test(x))
      return ctx.bestHour ? en('The cleanest hour today is around ' + ctx.bestHour + '.' + (ctx.worstHour ? ' The worst is around ' + ctx.worstHour + '.' : '')) : en('I do not have the best hour yet. Open the hourly forecast on page 1.');
    if (/forecast|tomorrow|tonight|later|next|पूर्वानुमान|कल|முன்னறிவிப்பு/.test(x))
      return en(ctx.forecast || 'The forecast summary is not available yet. Open the hourly forecast on page 1.');
    if (/\bwhy\b|reason|cause|क्यों|ஏன்/.test(x))
      return ctx.topDriver ? en('The biggest factor right now is ' + ctx.topDriver + '.') : en('I do not have the main cause yet. Open the explanation chart on page 2.');
    if (/temperature|how hot|तापमान|வெப்பநிலை/.test(x) && ctx.temp != null) return en('The temperature is ' + ctx.temp + ' degrees Celsius.');
    if (/wind|हवा की गति|காற்றின் வேகம்/.test(x) && ctx.wind != null) return en('Wind speed is ' + ctx.wind + ' kilometres per hour.');
    if (/humid|नमी|ஈரப்பதம்/.test(x) && ctx.humidity != null) return en('Humidity is ' + ctx.humidity + ' percent.');
    if (/safe|go out|outside|walk|run|jog|exercise|play|cycle|bike|market|बाहर|टहल|दौड़|வெளியே|நடை|బయట|ಹೊರಗೆ|പുറത്ത്/.test(x))
      return have ? advice() : noData;
    if (/air quality|aqi|how(?:'s| is) the air|pollution|वायु|हवा|प्रदूषण|காற்று|காற்றின்|தரம்|గాలి|ಗಾಳಿ|വായു/.test(x)) {
      if (!have) return noData;
      var cat = ctx.category || '';
      var TT = { te: ['లో ', 'గాలి నాణ్యత సూచిక ', ', ఇది ', '.'], kn: ['ನಲ್ಲಿ ', 'ಗಾಳಿಯ ಗುಣಮಟ್ಟ ಸೂಚ್ಯಂಕ ', ', ಇದು ', '.'], ml: ['ൽ ', 'വായു നിലവാര സൂചിക ', ', ഇത് ', '.'] };
      if (TT[l]) return { text: (city ? city + TT[l][0] : '') + TT[l][1] + aqi + (cat ? TT[l][2] + cat : '') + TT[l][3], lang: l };
      if (l === 'hi') return { text: (city ? city + ' में ' : '') + 'वायु गुणवत्ता सूचकांक ' + aqi + ' है' + (cat ? ', जो ' + cat + ' है।' : '।'), lang: 'hi' };
      if (l === 'ta') return { text: (city ? city + '-ல் ' : '') + 'காற்றுத் தரக் குறியீடு ' + aqi + (cat ? ', இது ' + cat + '.' : '.'), lang: 'ta' };
      return en((city ? 'In ' + city + ', the' : 'The') + ' air quality index is ' + aqi + (cat ? ', which is ' + cat : '') + '.' + (ctx.pm25 != null ? ' PM2.5 is ' + ctx.pm25 + ' micrograms per cubic metre.' : ''));
    }
    return pick(FALLBACK, l);
  }
  function answerLocally(q) {
    var ctx = {};
    try { ctx = (CFG.getContext && CFG.getContext()) || {}; } catch (e) { ctx = {}; }
    var r = localAnswer(q, ctx);
    st.history.push({ q: q, a: r.text });
    speak(r.text, r.lang);
  }

  function ask(q) {
    st.busy = true; stopRec(); setStatus('stThink'); beep([440]);
    var ctx = {};
    try { ctx = (CFG.getContext && CFG.getContext()) || {}; } catch (e) { ctx = {}; }
    ctx.language = langCode();
    var timeout = new Promise(function (_, rej) { setTimeout(function () { rej(new Error('timeout')); }, 25000); });
    Promise.race([Promise.resolve(CFG.ask(q, ctx, st.history.slice(-6))), timeout])
      .then(function (ans) {
        var out = clean(ans);
        if (!out) throw new Error('empty');
        st.history.push({ q: q, a: out });
        st.busy = false; speak(out);
      })
      .catch(function () { st.busy = false; speak(t('error')); });
  }

  /* --------------------------- off / tap to resume ----------------------- */
  function goOff() {
    st.mode = 'off'; stopRec(); cancelSpeech();
    clearTimeout(st.activeTimer); clearTimeout(st.idleTimer);
    setStatus('stOff'); beep([520, 390]);
    armResume();
  }
  function armResume() {
    if (st.resumeArmed) return;
    st.resumeArmed = true;
    var go = function () {
      document.removeEventListener('pointerdown', go, true); document.removeEventListener('keydown', go, true);
      st.resumeArmed = false;
      if (st.mode !== 'off') return;
      beep([880]); resetIdle(); openActive();
    };
    setTimeout(function () { document.addEventListener('pointerdown', go, true); document.addEventListener('keydown', go, true); }, 600);
  }

  /* -------------------------------- greeting ----------------------------- */
  function seenIntro() { try { return localStorage.getItem(INTRO) === '1'; } catch (e) { return false; } }
  function markIntro() { try { localStorage.setItem(INTRO, '1'); } catch (e) { /* ignore */ } }
  function greetText(first) {
    var h = new Date().getHours();
    var part = h >= 5 && h < 12 ? 'gm' : h < 17 && h >= 12 ? 'ga' : h >= 17 && h < 21 ? 'ge' : 'gn';
    var nice = (part === 'ge' || part === 'gn') ? t('nice2') : t('nice');
    return t(part) + '! ' + nice + ' ' + t('iam') + ' ' + t('tell') + (first ? ' ' + t('intro') : '');
  }
  function armGreetGesture() {
    if (st.gestureArmed || st.greeted) return;
    st.gestureArmed = true;
    var evs = ['pointerdown', 'keydown', 'touchstart', 'click'];
    var go = function () {
      evs.forEach(function (ev) { document.removeEventListener(ev, go, true); });
      st.gestureArmed = false; greet();
    };
    evs.forEach(function (ev) { document.addEventListener(ev, go, true); });
  }
  function greetParts(first) {
    var l = langCode(), parts = [[greetText(first), l]];
    if (first) { parts.push([t('help'), l]); parts = parts.concat(offerParts()); }
    return parts;
  }
  var skipH = null, SKIPEV = ['pointerdown', 'keydown'];
  function clearSkip() { if (skipH) { SKIPEV.forEach(function (ev) { document.removeEventListener(ev, skipH, true); }); skipH = null; } }
  function armSkip() {   // a tap or key during the long first-visit speech skips it and starts listening
    clearSkip();
    var h = function () { clearSkip(); st.sayId++; cancelSpeech(); resume(); };
    skipH = h;
    setTimeout(function () { if (skipH === h) SKIPEV.forEach(function (ev) { document.addEventListener(ev, h, true); }); }, 800);
  }
  function greet() {
    if (st.greeted) return;
    if (!('speechSynthesis' in window)) { st.greeted = true; resume(); return; }
    var first = !seenIntro(), started = false, parts = greetParts(first);
    var a = A(); if (a && a.caption) a.caption(parts[0][0]);
    say(parts, langCode(), function () {
      clearSkip();
      if (started) resume(); else armGreetGesture();
    }, function () { started = true; st.greeted = true; markIntro(); setStatus('stSpeak'); if (first) armSkip(); });
    // If the browser blocked sound (no tap yet), wait for the first tap, key press or screen-reader touch.
    setTimeout(function () {
      if (!started && !st.greeted) { try { window.speechSynthesis.cancel(); } catch (e) { /* ignore */ } armGreetGesture(); }
    }, 2500);
  }

  /* --------------------------------- UI ---------------------------------- */
  function setStatus(key) {
    if (!ui.pill) return;
    var show = CFG.showStatus && (key === 'stListen' || key === 'stThink' || key === 'stSpeak');
    ui.pill.style.display = show ? 'block' : 'none';
    if (show) ui.pill.textContent = t(key);
  }
  function init() {
    try { window.speechSynthesis.getVoices(); } catch (e) { /* ignore */ }
    var SR = window.SpeechRecognition || window.webkitSpeechRecognition;
    var s = document.createElement('style');
    s.textContent = '.av-pill{position:fixed;left:50%;transform:translateX(-50%);top:8px;z-index:99970;background:#0f172a;color:#fff;border:2px solid #fff;border-radius:999px;padding:6px 14px;font:700 13px system-ui,sans-serif;display:none;pointer-events:none}';
    document.head.appendChild(s);
    ui.pill = document.createElement('div'); ui.pill.className = 'av-pill'; ui.pill.setAttribute('aria-hidden', 'true');
    document.body.appendChild(ui.pill);
    try { var sl = localStorage.getItem('aircast_lang'); if (sl && STR[sl]) setLang(sl, true); } catch (e) { /* ignore */ }
    if (!SR) { st.mode = 'off'; return; }   // no voice support: stay silent, nothing to start
    document.addEventListener('keydown', function (e) {
      if (e.altKey && e.shiftKey && (e.key === 'H' || e.key === 'h')) { if (st.mode === 'off') { beep([880]); openActive(); } else goOff(); }
    });
    document.addEventListener('visibilitychange', function () {
      if (document.hidden) { stopRec(); cancelSpeech(); }
      else if (st.mode !== 'off' && st.greeted) { if (st.mode === 'active') openActive(); else startRec(); }
    });
    if (CFG.greet === false) { st.greeted = true; st.mode = 'standby'; startRec(); resetIdle(); }
    else { resetIdle(); setTimeout(greet, CFG.greetDelayMs); }
  }

  window.AirCastAssistant = {
    configure: function (o) { Object.keys(o || {}).forEach(function (k) { CFG[k] = o[k]; }); },
    start: function () { if (st.mode === 'off') { beep([880]); openActive(); } },
    stop: goOff,
    setLanguage: function (code) { if (STR[code]) { st.lang = code; stopRec(); if (st.mode !== 'off') startRec(); } },   // call when the app's own language dropdown changes
    ask: function (q) { if (st.mode === 'off') st.mode = 'active'; process(q); },
    greet: function () { st.greeted = false; greet(); }
  };
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init);
  else init();
})();
